package com.morningscanner.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecureStore {
    private static final String ALIAS = "morning_scanner_secure_v1";
    private static final String PREF = "secure_values";
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    private static SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (!store.containsAlias(ALIAS)) {
            KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            gen.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            return gen.generateKey();
        }
        return ((KeyStore.SecretKeyEntry) store.getEntry(ALIAS, null)).getSecretKey();
    }

    private static String encrypt(String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key());
        return Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + "." + Base64.encodeToString(cipher.doFinal(value.getBytes(StandardCharsets.UTF_8)), Base64.NO_WRAP);
    }

    private static String decrypt(String value) throws Exception {
        String[] p = value.split("\\.", 2);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)));
        return new String(cipher.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), StandardCharsets.UTF_8);
    }

    static void saveKeys(Context c, String appKey, String secret) throws Exception {
        String encryptedKey, encryptedSecret;
        try {
            encryptedKey=encrypt(appKey); encryptedSecret=encrypt(secret);
        } catch (Exception first) {
            KeyStore store=KeyStore.getInstance("AndroidKeyStore"); store.load(null); store.deleteEntry(ALIAS);
            encryptedKey=encrypt(appKey); encryptedSecret=encrypt(secret);
        }
        prefs(c).edit().putString("app_key", encryptedKey).putString("app_secret", encryptedSecret).remove("token").remove("token_expiry").apply();
    }
    static boolean hasKeys(Context c) { return prefs(c).contains("app_key") && prefs(c).contains("app_secret"); }
    static boolean keysUsable(Context c) { try { return hasKeys(c) && !appKey(c).isEmpty() && !appSecret(c).isEmpty(); } catch (Exception e) { return false; } }
    static String appKey(Context c) throws Exception { return decrypt(prefs(c).getString("app_key", "")); }
    static String appSecret(Context c) throws Exception { return decrypt(prefs(c).getString("app_secret", "")); }
    static void saveToken(Context c, String token, long expiry) throws Exception { prefs(c).edit().putString("token", encrypt(token)).putLong("token_expiry", expiry).apply(); }
    static String validToken(Context c) throws Exception {
        if (prefs(c).getLong("token_expiry", 0) < System.currentTimeMillis() + 120000) return null;
        String value = prefs(c).getString("token", null); return value == null ? null : decrypt(value);
    }
    static void clear(Context c) { prefs(c).edit().clear().apply(); }
}
