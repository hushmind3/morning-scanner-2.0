package com.morningscanner.app;

import android.content.Context;
import android.content.SharedPreferences;

final class UserPreferences {
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences("user_settings", Context.MODE_PRIVATE); }
    static boolean alarmEnabled(Context c) { return prefs(c).getBoolean("alarm_enabled", true); }
    static int alarmHour(Context c) { return prefs(c).getInt("alarm_hour", 8); }
    static int alarmMinute(Context c) { return prefs(c).getInt("alarm_minute", 30); }
    static String profile(Context c) { return prefs(c).getString("profile", "balanced"); }
    static void saveAlarm(Context c, boolean enabled, int hour, int minute) { prefs(c).edit().putBoolean("alarm_enabled", enabled).putInt("alarm_hour", hour).putInt("alarm_minute", minute).apply(); }
    static void saveProfile(Context c, String profile) { prefs(c).edit().putString("profile", validProfile(profile)).apply(); }
    static String validProfile(String profile) { return "stable".equals(profile) || "aggressive".equals(profile) ? profile : "balanced"; }
}
