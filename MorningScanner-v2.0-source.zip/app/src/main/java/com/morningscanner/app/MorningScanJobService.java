package com.morningscanner.app;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public class MorningScanJobService extends JobService {
    private static final int JOB_ID = 831;
    private ExecutorService executor;
    private volatile boolean stopped;

    static boolean enqueue(Context context) {
        JobScheduler scheduler=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        JobInfo job=new JobInfo.Builder(JOB_ID,new ComponentName(context,MorningScanJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setBackoffCriteria(30_000L,JobInfo.BACKOFF_POLICY_EXPONENTIAL)
                .build();
        return scheduler.schedule(job)==JobScheduler.RESULT_SUCCESS;
    }
    static void cancel(Context context) {
        ((JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE)).cancel(JOB_ID);
    }

    @Override public boolean onStartJob(JobParameters params) {
        stopped=false;
        executor=Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            boolean retry=false;
            try {
                NotificationHelper.createChannel(this);
                if (!SecureStore.keysUsable(this)) {
                    NotificationHelper.show(this,"예약 검색 대기","한투 API 키를 앱에서 다시 연결하세요.");
                } else {
                    JSONObject result=KisClient.scan(this,"auto",UserPreferences.profile(this));
                    result=ChangeTracker.annotate(result,ResultStore.load(this));
                    ResultStore.save(this,result);
                    String time=String.format(Locale.KOREA,"%02d:%02d",UserPreferences.alarmHour(this),UserPreferences.alarmMinute(this));
                    NotificationHelper.show(this,time+" 검색 완료",result.optInt("count")+"개 후보를 찾았습니다"+(result.optBoolean("partial")?" · 일부 API 실패":""));
                }
            } catch (Exception e) {
                retry=isTransient(e);
                NotificationHelper.show(this,"예약 검색 실패",e.getMessage()==null?"앱에서 연결 상태를 확인하세요.":e.getMessage());
            } finally {
                if(!stopped)jobFinished(params,retry);
            }
        });
        return true;
    }

    private static boolean isTransient(Throwable error) {
        for(Throwable cause=error;cause!=null;cause=cause.getCause())if(cause instanceof java.io.IOException)return true;
        String message=error.getMessage()==null?"":error.getMessage().toLowerCase(Locale.ROOT);
        return message.contains("timeout")||message.contains("timed out")||message.contains("connection reset")||message.contains("network")||message.contains("연결 실패");
    }

    @Override public boolean onStopJob(JobParameters params) {
        stopped=true;
        if(executor!=null)executor.shutdownNow();
        return true;
    }

    @Override public void onDestroy() {
        if(executor!=null)executor.shutdownNow();
        super.onDestroy();
    }
}
