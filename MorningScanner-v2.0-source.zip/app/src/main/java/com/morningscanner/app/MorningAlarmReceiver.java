package com.morningscanner.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class MorningAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        AlarmScheduler.schedule(context);
        if (UserPreferences.alarmEnabled(context) && !MorningScanJobService.enqueue(context)) {
            NotificationHelper.createChannel(context);
            NotificationHelper.show(context,"예약 검색 실패","안드로이드 작업 예약에 실패했습니다. 앱을 열어 다시 설정하세요.");
        }
    }
}
