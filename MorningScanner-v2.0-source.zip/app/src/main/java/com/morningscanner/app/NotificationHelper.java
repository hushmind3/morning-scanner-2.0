package com.morningscanner.app;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
final class NotificationHelper {
    private static final String CHANNEL = "morning_scan_results";
    static void createChannel(Context c) { if (Build.VERSION.SDK_INT >= 26) { NotificationChannel ch = new NotificationChannel(CHANNEL, "예약 종목 검색", NotificationManager.IMPORTANCE_HIGH); ch.setDescription("사용자가 설정한 시간의 종목 검색 결과"); ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch); } }
    static void show(Context c, String title, String text) {
        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 831, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(c, CHANNEL) : new android.app.Notification.Builder(c);
        b.setSmallIcon(com.morningscanner.app.R.drawable.ic_launcher).setContentTitle(title).setContentText(text).setContentIntent(pi).setAutoCancel(true);
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(830, b.build());
    }
}
