package com.morningscanner.app;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

final class KisClient {
    private static final String BASE="https://openapi.koreainvestment.com:9443";

    static JSONObject scan(Context context,String requestedMode,String requestedProfile) throws Exception {
        String profile=UserPreferences.validProfile(requestedProfile); String mode=resolveMode(requestedMode);
        String key=SecureStore.appKey(context),secret=SecureStore.appSecret(context),token=token(context,key,secret);
        String[][] segments={{"0001","KOSPI"},{"1001","KOSDAQ"}};
        LinkedHashMap<String,Candidate> pool=new LinkedHashMap<>(); JSONArray failures=new JSONArray(); int attempted=0,succeeded=0;
        for(String[] segment:segments){
            String[] venues="BOTH".equals(mode)?new String[]{"J","NX"}:new String[]{mode};
            for(String venue:venues){
                ApiBatch volume=fetch(key,secret,token,venue,segment[0],"volume");attempted++;if(volume.ok){succeeded++;merge(pool,volume.rows,venue,segment[1],"volume");}else failures.put(volume.error);
                pause();ApiBatch gain=fetch(key,secret,token,venue,segment[0],"gain");attempted++;if(gain.ok){succeeded++;merge(pool,gain.rows,venue,segment[1],"gain");}else failures.put(gain.error);
                pause();ApiBatch strength=fetch(key,secret,token,venue,segment[0],"strength");attempted++;if(strength.ok){succeeded++;merge(pool,strength.rows,venue,segment[1],"strength");}else failures.put(strength.error);pause();
            }
        }
        if(succeeded==0)throw new Exception(failures.length()>0?failures.optString(0,"한투 순위 API 조회 실패"):"한투 순위 API 조회 실패");
        List<Candidate> eligible=new ArrayList<>(); Profile config=Profile.of(profile);
        for(Candidate c:pool.values()){c.finish();if(c.name.isEmpty()||c.code.isEmpty()||excluded(c.name)||c.rate<config.minRate||c.rate>config.maxRate||c.price<1000||c.turnover<config.minTurnover)continue;eligible.add(c);}
        List<Candidate> kospi=group(eligible,"KOSPI"),kosdaq=group(eligible,"KOSDAQ");scoreGroup(kospi);scoreGroup(kosdaq);
        List<Candidate> ranked=new ArrayList<>();ranked.addAll(kospi);ranked.addAll(kosdaq);Collections.sort(ranked,(a,b)->Double.compare(b.score,a.score));
        int kospiUsed=0,kosdaqUsed=0;JSONArray stocks=new JSONArray();
        for(Candidate c:ranked){if(stocks.length()>=30||c.score<35)break;if("KOSPI".equals(c.segment)&&kospiUsed>=config.kospiMax)continue;if("KOSDAQ".equals(c.segment)&&kosdaqUsed>=config.kosdaqMax)continue;if("KOSPI".equals(c.segment))kospiUsed++;else kosdaqUsed++;stocks.put(c.json(stocks.length()+1));}
        JSONObject result=new JSONObject();result.put("success",true);result.put("market",mode);result.put("marketLabel",marketLabel(mode));result.put("profile",profile);result.put("profileLabel",config.label);
        result.put("comparisonKey",mode+":"+profile);result.put("scanned",pool.size());result.put("eligible",eligible.size());result.put("count",stocks.length());result.put("stocks",stocks);
        result.put("sourcesAttempted",attempted);result.put("sourcesSucceeded",succeeded);result.put("partial",succeeded<attempted);result.put("failures",failures);
        result.put("scannedAt",new SimpleDateFormat("MM월 dd일 HH:mm:ss",Locale.KOREA).format(new Date()));
        result.put("note",stocks.length()==0?"상대수급·상승·유동성 기준을 통과한 종목이 없습니다.":"코스피·코스닥을 분리해 상대 거래대금·회전율·체결강도를 분석했습니다.");return result;
    }

    private static String resolveMode(String requested){if("J".equals(requested)||"NX".equals(requested)||"BOTH".equals(requested))return requested;Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Asia/Seoul"));int s=c.get(Calendar.HOUR_OF_DAY)*3600+c.get(Calendar.MINUTE)*60+c.get(Calendar.SECOND);if(s>=8*3600&&s<8*3600+50*60)return "NX";if(s>=9*3600&&s<=20*3600)return "BOTH";return "J";}
    private static String marketLabel(String m){return "NX".equals(m)?"NXT":"J".equals(m)?"KRX":"KRX+NXT";}
    private static void pause(){try{Thread.sleep(90);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
    private static List<Candidate> group(List<Candidate> all,String segment){List<Candidate> out=new ArrayList<>();for(Candidate c:all)if(segment.equals(c.segment))out.add(c);return out;}

    private static void scoreGroup(List<Candidate> group){for(Candidate c:group){
        double flow=percentile(group,c,0),rotation=percentile(group,c,1),liquidity=percentile(group,c,2);
        double strength=c.strength>0?clamp((c.strength-85)/1.25,0,100):25;
        double momentum=clamp(100-Math.abs(c.rate-4.0)*12,0,100);
        double gap=c.openRate==0?50:clamp(100-Math.abs(c.openRate-2.5)*15,0,100);
        double multi=Math.min(8,(c.sources.size()-1)*4);double penalty=c.rate>8?(c.rate-8)*4:0;if(c.strength>300)penalty+=8;if(c.openRate>7)penalty+=(c.openRate-7)*3;
        c.score=clamp(flow*.25+rotation*.20+strength*.20+momentum*.15+gap*.10+liquidity*.10+multi-penalty,1,99);
    }}
    private static double percentile(List<Candidate> group,Candidate target,int metric){if(group.size()<2)return 50;double v=metric(target,metric);int below=0;for(Candidate c:group)if(metric(c,metric)<=v)below++;return 100.0*(below-1)/(group.size()-1);}
    private static double metric(Candidate c,int metric){if(metric==0)return c.avgTurnover>0?c.turnover/(double)c.avgTurnover:Math.max(0,c.volumeIncrease);if(metric==1)return c.turnoverRate>0?c.turnoverRate:c.listedShares>0?c.volume*100.0/c.listedShares:0;return Math.log10(c.turnover+1);}
    private static double clamp(double v,double min,double max){return Math.max(min,Math.min(max,v));}

    private static ApiBatch fetch(String key,String secret,String token,String venue,String segment,String kind){
        String path,trId;String[][] p;
        if("volume".equals(kind)){path="/uapi/domestic-stock/v1/quotations/volume-rank";trId="FHPST01710000";p=new String[][]{{"FID_COND_MRKT_DIV_CODE",venue},{"FID_COND_SCR_DIV_CODE","20171"},{"FID_INPUT_ISCD",segment},{"FID_DIV_CLS_CODE","1"},{"FID_BLNG_CLS_CODE","3"},{"FID_TRGT_CLS_CODE","111111111"},{"FID_TRGT_EXLS_CLS_CODE","0000000000"},{"FID_INPUT_PRICE_1",""},{"FID_INPUT_PRICE_2",""},{"FID_VOL_CNT",""}};}
        else if("gain".equals(kind)){path="/uapi/domestic-stock/v1/ranking/fluctuation";trId="FHPST01700000";p=new String[][]{{"fid_cond_mrkt_div_code",venue},{"fid_cond_scr_div_code","20170"},{"fid_input_iscd",segment},{"fid_rank_sort_cls_code","0"},{"fid_input_cnt_1","0"},{"fid_prc_cls_code","0"},{"fid_input_price_1",""},{"fid_input_price_2",""},{"fid_vol_cnt",""},{"fid_trgt_cls_code","0"},{"fid_trgt_exls_cls_code","0"},{"fid_div_cls_code","1"},{"fid_rsfl_rate1","0"},{"fid_rsfl_rate2","15"}};}
        else{path="/uapi/domestic-stock/v1/ranking/volume-power";trId="FHPST01680000";p=new String[][]{{"fid_trgt_exls_cls_code","0"},{"fid_cond_mrkt_div_code",venue},{"fid_cond_scr_div_code","20168"},{"fid_input_iscd",segment},{"fid_div_cls_code","1"},{"fid_input_price_1",""},{"fid_input_price_2",""},{"fid_vol_cnt",""},{"fid_trgt_cls_code","0"}};}
        try{
            StringBuilder q=new StringBuilder();for(String[] x:p){if(q.length()>0)q.append('&');q.append(URLEncoder.encode(x[0],"UTF-8")).append('=').append(URLEncoder.encode(x[1],"UTF-8"));}
            HttpURLConnection conn=(HttpURLConnection)new URL(BASE+path+"?"+q).openConnection();conn.setRequestMethod("GET");conn.setConnectTimeout(8000);conn.setReadTimeout(12000);
            conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");conn.setRequestProperty("Accept","application/json");conn.setRequestProperty("authorization","Bearer "+token);conn.setRequestProperty("appkey",key);conn.setRequestProperty("appsecret",secret);conn.setRequestProperty("tr_id",trId);conn.setRequestProperty("custtype","P");
            JSONObject r=readJson(conn);if(!"0".equals(r.optString("rt_cd")))return ApiBatch.fail(venue+" "+segmentName(segment)+" "+kindName(kind)+": "+cleanMessage(r.optString("msg1","조회 실패")));
            JSONArray rows=r.optJSONArray("output");return ApiBatch.ok(rows==null?new JSONArray():rows);
        }catch(Exception e){return ApiBatch.fail(venue+" "+segmentName(segment)+" "+kindName(kind)+": "+cleanMessage(e.getMessage()));}
    }
    private static String segmentName(String s){return "0001".equals(s)?"코스피":"코스닥";}private static String kindName(String k){return "volume".equals(k)?"거래대금":"gain".equals(k)?"상승률":"체결강도";}

    private static void merge(Map<String,Candidate> pool,JSONArray rows,String venue,String segment,String kind){for(int i=0;i<rows.length();i++){
        JSONObject r=rows.optJSONObject(i);if(r==null)continue;String code=first(r,"mksc_shrn_iscd","stck_shrn_iscd");if(code.isEmpty())continue;Candidate c=pool.get(code);if(c==null){c=new Candidate(code,segment);pool.put(code,c);}c.segment=segment;c.venues.add(venue);c.sources.add(kind);
        String name=r.optString("hts_kor_isnm").trim();if(!name.isEmpty())c.name=name;long price=whole(r.optString("stck_prpr"));if(price>0)c.price=price;double rate=number(r.optString("prdy_ctrt"));if(rate!=0)c.rate=rate;
        long volume=whole(r.optString("acml_vol"));long turnover=whole(r.optString("acml_tr_pbmn"));
        if("volume".equals(kind)){
            if(volume>0)c.venueVolume.put(venue,Math.max(c.venueVolume.containsKey(venue)?c.venueVolume.get(venue):0,volume));
            if(turnover>0)c.venueTurnover.put(venue,Math.max(c.venueTurnover.containsKey(venue)?c.venueTurnover.get(venue):0,turnover));
            long average=whole(r.optString("avrg_tr_pbmn"));if(average>0)c.venueAvgTurnover.put(venue,Math.max(c.venueAvgTurnover.containsKey(venue)?c.venueAvgTurnover.get(venue):0,average));
        }else if(volume>0)c.fallbackVolume=Math.max(c.fallbackVolume,volume);
        c.volumeIncrease=Math.max(c.volumeIncrease,number(r.optString("vol_inrt")));c.turnoverRate=Math.max(c.turnoverRate,number(r.optString("tr_pbmn_tnrt")));c.listedShares=Math.max(c.listedShares,whole(r.optString("lstn_stcn")));
        int rank=(int)whole(r.optString("data_rank"));if(rank<=0)rank=i+1;if("volume".equals(kind))c.volumeRank=Math.min(c.volumeRank,rank);else if("gain".equals(kind)){c.gainRank=Math.min(c.gainRank,rank);double o=number(r.optString("oprc_vrss_prpr_rate"));if(o!=0)c.openRate=o;}else{c.strengthRank=Math.min(c.strengthRank,rank);c.strength=Math.max(c.strength,number(r.optString("tday_rltv")));}
    }}
    private static String first(JSONObject r,String a,String b){String v=r.optString(a).trim();return v.isEmpty()?r.optString(b).trim():v;}

    private static String token(Context context,String key,String secret)throws Exception{String cached=SecureStore.validToken(context);if(cached!=null)return cached;HttpURLConnection conn=(HttpURLConnection)new URL(BASE+"/oauth2/tokenP").openConnection();conn.setRequestMethod("POST");conn.setDoOutput(true);conn.setConnectTimeout(12000);conn.setReadTimeout(15000);conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");JSONObject body=new JSONObject();body.put("grant_type","client_credentials");body.put("appkey",key);body.put("appsecret",secret);try(OutputStream os=conn.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}JSONObject r=readJson(conn);String value=r.optString("access_token");if(value.isEmpty())throw new Exception(cleanMessage(r.optString("error_description",r.optString("msg1","한투 API 인증 실패"))));long expires=r.optLong("expires_in",86400);SecureStore.saveToken(context,value,System.currentTimeMillis()+expires*1000L);return value;}
    private static JSONObject readJson(HttpURLConnection conn)throws Exception{int status=conn.getResponseCode();InputStream stream=status>=200&&status<300?conn.getInputStream():conn.getErrorStream();if(stream==null)throw new Exception("서버 응답 없음 (HTTP "+status+")");StringBuilder text=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)text.append(line);}try{return new JSONObject(text.toString());}catch(Exception e){throw new Exception("한투 응답 해석 실패 (HTTP "+status+")");}}
    static JSONObject error(Exception e){JSONObject r=new JSONObject();try{r.put("success",false);r.put("message",cleanMessage(e.getMessage()));}catch(Exception ignored){}return r;}
    private static String cleanMessage(String m){if(m==null||m.trim().isEmpty())return "알 수 없는 오류";return m.length()>180?m.substring(0,180):m;}
    private static double number(String s){try{return Double.parseDouble(s.replace(",","").trim());}catch(Exception e){return 0;}}private static long whole(String s){try{return new java.math.BigDecimal(s.replace(",","").trim()).longValue();}catch(Exception e){return 0;}}
    private static boolean excluded(String n){String u=n.toUpperCase(Locale.ROOT);String[] x={"스팩","SPAC","ETF","ETN","KODEX","TIGER","KOSEF","KBSTAR","RISE","SOL ","ACE ","PLUS ","인버스","레버리지"};for(String v:x)if(u.contains(v))return true;return false;}
    private static String compact(long v){if(v>=100000000)return String.format(Locale.KOREA,"%.1f억",v/100000000.0);if(v>=10000)return String.format(Locale.KOREA,"%.1f만",v/10000.0);return String.format(Locale.KOREA,"%,d",v);}private static String money(long v){if(v>=1000000000000L)return String.format(Locale.KOREA,"%.2f조",v/1000000000000.0);if(v>=100000000)return String.format(Locale.KOREA,"%.1f억",v/100000000.0);return String.format(Locale.KOREA,"%,d원",v);}

    private static final class ApiBatch{final boolean ok;final JSONArray rows;final String error;private ApiBatch(boolean o,JSONArray r,String e){ok=o;rows=r;error=e;}static ApiBatch ok(JSONArray r){return new ApiBatch(true,r,"");}static ApiBatch fail(String e){return new ApiBatch(false,new JSONArray(),e);}}
    private static final class Profile{final String label;final double minRate,maxRate;final long minTurnover;final int kospiMax,kosdaqMax;private Profile(String l,double min,double max,long amount,int p,int q){label=l;minRate=min;maxRate=max;minTurnover=amount;kospiMax=p;kosdaqMax=q;}static Profile of(String p){if("stable".equals(p))return new Profile("안정형",.3,8,500000000L,20,10);if("aggressive".equals(p))return new Profile("공격형",1,20,50000000L,10,20);return new Profile("균형형",.5,12,100000000L,15,15);}}
    private static final class Candidate{
        final String code;String name="",segment;long price,volume,turnover,avgTurnover,listedShares,fallbackVolume;double rate,volumeIncrease,turnoverRate,strength,openRate,score;int volumeRank=999,gainRank=999,strengthRank=999;final Map<String,Long> venueVolume=new HashMap<>(),venueTurnover=new HashMap<>(),venueAvgTurnover=new HashMap<>();final Set<String> venues=new HashSet<>(),sources=new HashSet<>();
        Candidate(String c,String s){code=c;segment=s;}void finish(){volume=0;turnover=0;avgTurnover=0;for(long v:venueVolume.values())volume+=v;for(long v:venueTurnover.values())turnover+=v;for(long v:venueAvgTurnover.values())avgTurnover+=v;if(volume<=0)volume=fallbackVolume;if(turnover<=0&&price>0&&volume>0)turnover=price*volume;}
        JSONObject json(int rank)throws Exception{JSONObject o=new JSONObject();o.put("rank",rank);o.put("code",code);o.put("name",name);o.put("segment",segment);o.put("venue",venues.contains("UN")?"통합":venues.contains("J")&&venues.contains("NX")?"KRX+NXT":venues.contains("NX")?"NXT":"KRX");o.put("price",price);o.put("changeRate",rate);o.put("volume",volume);o.put("turnover",turnover);o.put("volumeIncrease",volumeIncrease);o.put("turnoverRate",turnoverRate);o.put("strength",strength);o.put("openRate",openRate);o.put("score",Math.round(score));o.put("signalCount",sources.size());JSONArray reasons=new JSONArray();
            reasons.put(String.format(Locale.KOREA,"전일대비 +%.2f%%",rate));if(avgTurnover>0)reasons.put(String.format(Locale.KOREA,"평균 대비 거래대금 %.1f배",turnover/(double)avgTurnover));else reasons.put("누적 거래대금 "+money(turnover));
            if(volumeIncrease>0)reasons.put(String.format(Locale.KOREA,"거래량 증가율 %.1f%%",volumeIncrease));if(turnoverRate>0)reasons.put(String.format(Locale.KOREA,"거래대금 회전율 %.2f%%",turnoverRate));if(strength>0)reasons.put(String.format(Locale.KOREA,"체결강도 %.1f%%",strength));if(openRate!=0)reasons.put(String.format(Locale.KOREA,"시가 대비 %.2f%%",openRate));if(sources.size()>=2)reasons.put(sources.size()+"개 순위에서 동시 포착");o.put("reasons",reasons);return o;}
    }
}
