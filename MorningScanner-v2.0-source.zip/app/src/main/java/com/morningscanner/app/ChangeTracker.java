package com.morningscanner.app;

import java.util.HashMap;
import java.util.HashSet;
import org.json.JSONArray;
import org.json.JSONObject;

final class ChangeTracker {
    static JSONObject annotate(JSONObject current, JSONObject previous) {
        try {
            if (current == null || !current.optBoolean("success")) return current;
            if (previous == null || !previous.optBoolean("success") || !current.optString("comparisonKey").equals(previous.optString("comparisonKey"))) {
                JSONArray rows = current.optJSONArray("stocks"); if (rows != null) for (int i=0;i<rows.length();i++) rows.optJSONObject(i).put("movement", "NEW");
                current.put("dropped", new JSONArray()); return current;
            }
            HashMap<String,JSONObject> old = new HashMap<>(); JSONArray oldRows = previous.optJSONArray("stocks");
            if (oldRows != null) for (int i=0;i<oldRows.length();i++) { JSONObject row=oldRows.optJSONObject(i); if(row!=null) old.put(row.optString("code"),row); }
            HashSet<String> now = new HashSet<>(); JSONArray rows = current.optJSONArray("stocks");
            if (rows != null) for (int i=0;i<rows.length();i++) {
                JSONObject row=rows.optJSONObject(i); if(row==null) continue; String code=row.optString("code"); now.add(code); JSONObject before=old.get(code);
                if(before==null){row.put("movement","NEW");row.put("rankDelta",0);} else {int delta=before.optInt("rank")-row.optInt("rank");row.put("rankDelta",delta);row.put("movement",delta>0?"UP":delta<0?"DOWN":"SAME");row.put("priceDelta",row.optLong("price")-before.optLong("price"));}
            }
            JSONArray dropped=new JSONArray(); for(JSONObject row:old.values()) if(!now.contains(row.optString("code"))){JSONObject d=new JSONObject();d.put("code",row.optString("code"));d.put("name",row.optString("name"));d.put("oldRank",row.optInt("rank"));dropped.put(d);if(dropped.length()>=12)break;}
            current.put("dropped",dropped); return current;
        } catch(Exception ignored){return current;}
    }
}
