package com.morningscanner.app;
import android.content.Context;
import org.json.JSONObject;
final class ResultStore {
    static void save(Context c, JSONObject value) { c.getSharedPreferences("results", Context.MODE_PRIVATE).edit().putString("last", value.toString()).apply(); }
    static JSONObject load(Context c) { try { String s = c.getSharedPreferences("results", Context.MODE_PRIVATE).getString("last", null); return s == null ? null : new JSONObject(s); } catch (Exception e) { return null; } }
    static void clear(Context c) { c.getSharedPreferences("results", Context.MODE_PRIVATE).edit().clear().apply(); }
}
