package com.morningscanner.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;
import java.util.TimeZone;

final class AlarmScheduler {
    private static PendingIntent pending(Context c) {
        Intent intent = new Intent(c, MorningAlarmReceiver.class).setAction("com.morningscanner.DAILY_SCAN");
        return PendingIntent.getBroadcast(c, 830, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    static void schedule(Context c) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pending(c));
        if (!UserPreferences.alarmEnabled(c)) { MorningScanJobService.cancel(c); return; }
        long at = nextEpoch(c);
        if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(c));
        else if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(c));
        else am.setExact(AlarmManager.RTC_WAKEUP, at, pending(c));
    }
    static long nextEpoch(Context c) {
        TimeZone zone=TimeZone.getTimeZone("Asia/Seoul"); Calendar now=Calendar.getInstance(zone); Calendar next=Calendar.getInstance(zone);
        next.set(Calendar.HOUR_OF_DAY,UserPreferences.alarmHour(c)); next.set(Calendar.MINUTE,UserPreferences.alarmMinute(c)); next.set(Calendar.SECOND,0); next.set(Calendar.MILLISECOND,0);
        if(!next.after(now))next.add(Calendar.DAY_OF_YEAR,1); return next.getTimeInMillis();
    }
    static boolean canScheduleExact(Context c) { return Build.VERSION.SDK_INT < 31 || ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms(); }
}
