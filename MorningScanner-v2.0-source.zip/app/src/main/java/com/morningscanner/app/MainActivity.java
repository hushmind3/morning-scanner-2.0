package com.morningscanner.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        NotificationHelper.createChannel(this); AlarmScheduler.schedule(this);
        webView = new WebView(this); WebView.setWebContentsDebuggingEnabled(false);
        WebSettings settings = webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false); settings.setAllowContentAccess(false); settings.setSaveFormData(false);
        settings.setBlockNetworkLoads(true); settings.setJavaScriptCanOpenWindowsAutomatically(false); settings.setSupportMultipleWindows(false);
        webView.setBackgroundColor(0xff080b10); webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){return true;}
            @SuppressWarnings("deprecation") @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return true;}
        }); webView.addJavascriptInterface(new AppBridge(), "AndroidApp"); setContentView(webView);
        try {
            InputStream in=getAssets().open("index.html"); ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buffer=new byte[8192]; int n;
            while((n=in.read(buffer))!=-1)out.write(buffer,0,n); String html=out.toString(StandardCharsets.UTF_8.name());
            webView.loadDataWithBaseURL("https://app.local/",html,"text/html","UTF-8",null);
        } catch(Exception e){webView.loadData("<h2 style='color:white;background:#080b10;padding:24px'>화면 로드 실패: "+e.getClass().getSimpleName()+"</h2>","text/html","UTF-8");}
    }

    @Override protected void onResume(){super.onResume();AlarmScheduler.schedule(this);if(webView!=null)sendStatus();}
    @Override protected void onDestroy(){executor.shutdownNow();if(webView!=null)webView.destroy();super.onDestroy();}

    private void js(String function,JSONObject payload){String encoded=JSONObject.quote(payload.toString());webView.post(()->webView.evaluateJavascript("window."+function+"("+encoded+")",null));}
    private void sendStatus(){
        JSONObject status=new JSONObject();try{
            status.put("hasKeys",SecureStore.keysUsable(this));status.put("alarmExact",AlarmScheduler.canScheduleExact(this));status.put("alarmEnabled",UserPreferences.alarmEnabled(this));
            status.put("alarmHour",UserPreferences.alarmHour(this));status.put("alarmMinute",UserPreferences.alarmMinute(this));status.put("profile",UserPreferences.profile(this));
            SimpleDateFormat alarmFormat=new SimpleDateFormat("MM/dd HH:mm",Locale.KOREA);alarmFormat.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Seoul"));
            status.put("nextAlarm",UserPreferences.alarmEnabled(this)?alarmFormat.format(new Date(AlarmScheduler.nextEpoch(this))):"");
            status.put("lastResult",ResultStore.load(this));
        }catch(Exception ignored){}js("onAppStatus",status);
    }

    private JSONObject scanAndStore(String market,String profile) throws Exception {
        JSONObject previous=ResultStore.load(this);JSONObject result=KisClient.scan(this,market,UserPreferences.validProfile(profile));
        result=ChangeTracker.annotate(result,previous);ResultStore.save(this,result);UserPreferences.saveProfile(this,profile);return result;
    }

    private void requestExactAlarmAccessIfNeeded(){
        if(Build.VERSION.SDK_INT>=31){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);if(!am.canScheduleExactAlarms())try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,android.net.Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}
    }
    private void requestAlarmAccessIfNeeded(){
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},830);
        else requestExactAlarmAccessIfNeeded();
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==830)requestExactAlarmAccessIfNeeded();}

    public final class AppBridge {
        @JavascriptInterface public void ready(){sendStatus();}
        @JavascriptInterface public void saveKeys(String appKey,String appSecret,String profile){executor.execute(()->{JSONObject result;try{
            if(appKey==null||appKey.trim().length()<10||appSecret==null||appSecret.trim().length()<10)throw new Exception("App Key와 App Secret을 정확히 입력하세요.");
            SecureStore.saveKeys(MainActivity.this,appKey.trim(),appSecret.trim());result=scanAndStore("auto",profile);
        }catch(Exception e){result=KisClient.error(e);}sendStatus();js("onScanResult",result);});}
        @JavascriptInterface public void scan(String market,String profile){executor.execute(()->{JSONObject result;try{
            if(!SecureStore.keysUsable(MainActivity.this))throw new Exception("먼저 한투 API 키를 연결하세요.");result=scanAndStore(market,profile);
        }catch(Exception e){result=KisClient.error(e);}js("onScanResult",result);});}
        @JavascriptInterface public void clearKeys(){SecureStore.clear(MainActivity.this);ResultStore.clear(MainActivity.this);sendStatus();}
        @JavascriptInterface public void saveAlarm(int hour,int minute,boolean enabled,String profile){
            JSONObject response=new JSONObject();try{
                if(hour<0||hour>23||minute<0||minute>59)throw new Exception("알람 시간을 정확히 입력하세요.");
                UserPreferences.saveAlarm(MainActivity.this,enabled,hour,minute);UserPreferences.saveProfile(MainActivity.this,profile);AlarmScheduler.schedule(MainActivity.this);
                response.put("success",true);response.put("enabled",enabled);
            }catch(Exception e){try{response.put("success",false);response.put("message",e.getMessage());}catch(Exception ignored){}}
            js("onAlarmSaved",response);runOnUiThread(()->{if(enabled)requestAlarmAccessIfNeeded();sendStatus();});
        }
    }
}
